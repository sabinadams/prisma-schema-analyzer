
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sabinadams',
  applicationName: 'prisma-analyzer',
  appUid: '0L2HNJWcmgBlDvj8RD',
  orgUid: 'bf867972-8bae-4d6b-95b5-7fc35811f3f8',
  deploymentUid: 'bc67556c-7ead-4f49-aca3-573c2b5ab8ec',
  serviceName: 'remix-serverless-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'remix-serverless-app-dev-remix', timeout: 6 };

try {
  const userHandler = require('./server/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}